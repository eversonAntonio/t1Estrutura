/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufms.t1Estruturas.model;

import javafx.scene.control.TextArea;

/**
 *
 * @author PC
 */
public class TextoASerSalvo {
    
    public static TextArea mostraVetores;
    
}
